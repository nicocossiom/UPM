package com.geoetsiinf.client;

public class API {
    private String treasures;
    public String getTreasures() {
		return treasures;
	}

	public void setTreasures(String treasures) {
		this.treasures = treasures;
	}

	public String getUsers() {
		return users;
	}

	public void setUsers(String users) {
		this.users = users;
	}

	private String users;
	
}
